#!/bin/ksh -avx

### *************** CURRENT PAGERS *****************
export echaffin='2063908477@txt.att.net'
export erunkle='2063908477@txt.att.net'
export jcorrell='2064918849@vtext.com'
export jiehou='2066615808@txt.att.net'
#export plo='4259228335@txt.att.net'
#export siyoo='2065716251@vtext.com'
export walker='2063143462@usamobility.net'
export wendych='2064993151@txt.att.net'
export sean='6026723916@'tmomail.net' 

export dba_team=" $echaffin $jiehou $jcorrell $walker $wendych $siyoo $sean"
export dba_oncall=" $dba_team "
export dba_unix=" $echaffin $jcorrell $jiehou $sean"

